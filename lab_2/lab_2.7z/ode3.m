% ode 3
yn2= @(tn,yn,yn1) yn1+1.5*h*;
y_diff(1,2);
