xlabel('iteration');
ylabel('distance');
name = {['Lab 8.2 TSP 11612001 ����'],['Opt Distance ',num2str(disOpt)]};
title(name);

saveas(gcf,'E:\7-2018�＾ѧ��\LAB\nonLinearOpt\lab_8\lab_8_2\plot\1.png');