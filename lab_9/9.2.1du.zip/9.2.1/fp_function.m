function y = fp_function(x)

temp1 = 0; temp2 = 0;
for i = 1:8
    temp1 = temp1 + (x(i)-1/sqrt(8)).^2;
    temp2 = temp2 + (x(i)+1/sqrt(8)).^2;
end

y(1) = 1-exp(-temp1);
y(2) = 1-exp(-temp2);
