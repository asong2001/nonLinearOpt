function S = mating(P,N,d_mating)
%% mate restriction avoid local minima
d = zeros(N,N);
% calculate the distance between points;
for i = 1:N
    for j = 1:N
        dis = P(:,i) - P(:,j);
        d(i,j) = norm(dis);
        % if select two same point, then Inf to avoid effect
        if i == j
            d(i,j) = Inf;
        end
    end
end

for i = 1:N
    % find the minimum distance around the point
    min_d = min(d(i,:));
    n = find(d(i,:) == min_d);
    a = rand(1);b = randi(N);
    % if the minimum distance is smaller than restriction. then Do mating
    if min_d < d_mating
        S(:,i) = a*P(:,i) + (1-a)*P(:,n(1));
    else
    % else picking random points
        S(:,i) = a*P(:,i) + (1-a)*P(:,b);
    end
end