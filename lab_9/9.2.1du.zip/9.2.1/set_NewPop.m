function n_Pop = set_NewPop(P,Elit,N)

n = 5 + randi(30);
for i = 1:n
    n_Pop(:,i) = Elit(:,randi(N));
end

for i = n+1:N
    n_Pop(:,i) = P(:,randi(N));
end