function s = select(P,fit,N)
%% select the son generation
h = 1;
% we need N son, so we iterate N times;
while h <= N
    % random pick two individuals and a subset of Pop
    i = randi(N); j = randi(N); k = randperm(N,70);
    
    for o = 1:length(k)
        comp_set(o) = fit(k(o));
    end
    % find the best fitness of this subset
    max_fit = max(comp_set);
    
    % set two individuals is not good at first;
    c1_domina = false; c2_domina = false;
    
    c1 = fit(i); c2 = fit(j);
    % if an individual is better than all subset, then it's a
    % good(dominate) one;
    if c1 >= max_fit
        c1_domina = true;
    end
    
    if c2 >= max_fit
        c2_domina = true;
    end
    
    % if both are better or worse than subset, then compare their fitness
    if c1_domina == c2_domina
        % pick one have better fitness
        if c1 > c2
            s(:,h) = P(:,i);
        else
            s(:,h) = P(:,j);
        end
    else
        % if one is good and one is bad, pick the good one;
        if c1_domina == false
            s(:,h) = P(:,j);
        else
            s(:,h) = P(:,i);
        end
    end
    
    h = h + 1;
end