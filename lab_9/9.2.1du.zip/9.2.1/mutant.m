function n_Pop = mutant(Pop,m_prob,N,m)
%% do mutant
n_Pop = Pop;
for i = 1:N
    % if a is small than probability ,then mutant that indi.
    if rand(1) < m_prob
        k = randi(m);
        n_Pop(k,i) = Pop(k,i) + 0.5*rand(1)*(-1)^(randi(10));
    else
        k = randi(m);
        n_Pop(k,i) = Pop(k,i);
    end
end