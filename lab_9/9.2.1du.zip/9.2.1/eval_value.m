function y = eval_value(f,P,N)

for i = 1:N
    y(:,i) = fp_function(P(:,i));
end