function [Elit,ey,P] = elitism(fit,y,N,o_Elit,o_ey,n_P,o_P)
%% select the best one
% save the current fitness
% order of current is add 100 to distinguished with old order
temp_fit = [fit;101:N+100];
% add the current fitness to old one
temp_E = [o_Elit temp_fit];
% sort the temp Elit to get the best individuals at front;
n_E = sortrows(temp_E','descend')';
% if size of Elit is over the limit, then discard the worst ones
while length(n_E(1,:)) > 100
    n_E = n_E(:,1:(length(n_E)-100));
end
% get the y value of this new Elit Pop.
for i = 1:length(n_E)
    Elit(1,i) = n_E(1,i);
    % if order is larger than that is a new one,else it is a old one;
    if n_E(2,i) <= 100
        ey(:,i) = o_ey(:,n_E(2,i));
        P(:,i) = n_P(:,n_E(2,i));
    else
        ey(:,i) = y(:,n_E(2,i)-100);
        P(:,i) = o_P(:,n_E(2,i)-100);
    end
end
% set the new order
Elit(2,:) = 1:length(Elit);