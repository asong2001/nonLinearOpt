function Pop_f = init_pop(N,n,ub,lb)

Pop_f = zeros(n,N);
for j = 1:n
    for i = 1:N
        % generated values that located in bounded area
        Pop_f(j,i) = (ub-lb)*rand(1)-ub;
    end
end