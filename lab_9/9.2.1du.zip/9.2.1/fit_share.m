function [n_fit] = fit_share(y,fit,N,d_share,alpha)
%% calculate the distance between points
d = zeros(N,N);SF = d;
for i = 1:N
    for j = 1:N
        dis = [y(1,i) y(2,i)]-[y(1,j) y(2,j)];
        d(i,j) = norm(dis);
        if i == j
            % if we calculate self point, we set it to be Inf so that will
            % not affect the result.
            d(i,j) = 0;
        end
    end
end

for i = 1:N
    for j = 1:N
        % if distance smaller than allowed distance which means it is too
        % crowd. we will calculte a SF to adjust the delta sharing
        if d(i,j) < d_share
            SF(i,j) = 1 - (d(i,j)/d_share).^alpha;
        else
            SF(i,j) = 0;
        end
    end
end
n_fit = fit;

% if many points around you, the fitness will become small which means the
% fitness of the point become worse
for k = 1:N
    temp = sum(SF(k,:));
    n_fit(k) = fit(k)/temp;
end