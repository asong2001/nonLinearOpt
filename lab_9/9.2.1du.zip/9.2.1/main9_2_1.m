clc;
clear;
%% Set the basic constant

N = 100; ub = 2;                % N is Pop Size;

lb = -2; n = 8;                 % lb and ub is tow bound;

f = "fp";                       % f determined the obj function;

d_share = 0.7;                  % d_share is delta share in fitness sharing;

alpha = 0.1;                    % alpha is alpha in dynamic sharing adjust

d_mating = 3;                 % d_mating is delta_mating which is the maximum distance that can do mating;

kmax = 500;                     % kmax is the iteration time;

o_Elit = []; o_ey = [];         % o_Elit and o_ey is initial setting of Elit fit and their y;

m_prob = 0.8;                   % m_prob is the probability of mutant;
%% Calculation


Pop = init_pop(N,n,ub,lb);          % Initialize the population;

o_P = Pop;                          % set a o_P to save preview Pop;
k = 0;

[x1,fval] = gamultiobj(@fp_function,8,[],[],[],[],-2,2);

while k < kmax
   
    d_mating = 3*d_share;                           % calculate the new delta mating according to delta sharing;
    
    clf;                                            % clear the plot window
    
    y = eval_value(f,Pop,N);                        % evaluate the function value y of the Pop;
    
    [fit,rank] = indi_acce(y,N);                    % based on function value y to evaluate fitness and ranking;
    plot(y(1,:),y(2,:),'bo');xlim([0 1]); ylim([0 1]);hold on;
    
    n_fit = fit_share(y,fit,N,d_share,alpha);       % adjust fit sharing based on the distance;
    
    % d_share = dynamic_share(y,N);                   % calculate the new dynamic sharing
    
    [Elit,ey,o_P] = elitism(n_fit,y,N,o_Elit,o_ey,Pop,o_P);         % select the Elit pop based on this fit, previous Elit
    plot(ey(1,:),ey(2,:),'ro');hold on;
    plot(fval(:,1),fval(:,2),'k*');
    
    o_ey = ey; o_Elit = Elit;       % make new Elit to be old Elit
    
    s = select(Pop,n_fit,N);        % select the new son generation based on fitness
    
    n_Pop = set_NewPop(s,o_P,N);
    
    S = mating(n_Pop,N,d_mating);       % Do mating crossing based on new son;
    
    Pop = mutant(S,m_prob,N,n);     % Mutant happened in this son generation;
    k = k + 1;
    pause(0.2);
end