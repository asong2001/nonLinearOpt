clc;
clear;

fitness = @fp_function;
nvar = 8;

options = optimoptions('gamultiobj','PlotFcn',@gaplotpareto);
figure(1)
[x1,fval1,exitflag1,output1] = gamultiobj(@fp_function,8,[],[],[],[],-2,2,options);
figure(2);
[x2,fval2,exitflag2,output2] = gamultiobj(@ft_function,3,[],[],[],[],[0.5 -2 -2],[1 2 2],options);