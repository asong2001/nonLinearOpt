function d_share = dynamic_share(y,N)
%% calculate the new delta sharing
Fz(1,1) = min(y(1,:)); Fz(2,1) = min(y(2,:));

max = 0;
% calculate the distance betweent the points and find the max pair.
for i = 1:N
    for j = 1:N
        dis = [y(1,i) y(2,i)]-[y(1,j) y(2,j)];
        if max < norm(dis)
            mx = i; my = j; max = norm(dis);
        end
    end
end

Fx = y(:,mx); Fy = y(:,my);
d1 = norm(Fx - Fz); d2 = norm(Fy - Fz);
d_min = sqrt(d1^2+d2^2); d_max = d1+d2;
d = (d_min + d_max)/2;

d_share = N*(d/2);