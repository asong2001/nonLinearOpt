function [fit,rank] = indi_acce(y,N)
%% Calculate the ranking of point
rank = ones(1,N);
% if exist a point that y1 and y2 both small then the point, the rank add 1
for i = 1:N
    px = y(1,i); py = y(2,i);
    for j = 1:N
        if y(1,j) < px && y(2,j) < py
            rank(i) = rank(i) + 1;
        end
    end
end

fit = 1./rank;